import React, { useState } from "react";
import "./App.css";

function App() {
  const [cartItems, setCartItems] = useState([]);

  const items = [
  { id: 1, name: "LipStick", price: 100, description: "Adds color and moisture." },
  { id: 2, name: "Foundation", price: 250, description: "Evens out skin tone." },
  { id: 3, name: "Mascara ", price: 330, description: "Volumizes and darkens lashes." },
  { id: 4, name: "Eyeliner", price: 340, description: "Defines the eyes." },
  { id: 5, name: "Blush", price: 250, description: "Adds a healthy flush of color to cheeks." },  
  { id: 6, name: "Concealer", price: 160, description: "Covers blemishes, dark circles, or redness." },
  { id: 7, name: "Highlighter", price: 270, description: " Accents high points of the face for glow." },
  { id: 8, name: "Bronzer", price: 380, description: "Adds warmth and dimension to the face." },
  { id: 9, name: "Setting Spray", price: 190, description: "Locks makeup in place for all-day wear." },

  ];

  const addToCart = (item) => {
    const existingItem = cartItems.find(
      (cartItem) => cartItem.id === item.id
    );

    if (existingItem) {
      setCartItems(
        cartItems.map((cartItem) =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        )
      );
    } else {
      setCartItems([...cartItems, { ...item, quantity: 1 }]);
    }
  };

  const removeFromCart = (id) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  const updateQuantity = (id, amount) => {
    const updatedCart = cartItems
      .map((item) =>
        item.id === id
          ? { ...item, quantity: item.quantity + amount }
          : item
      )
      .filter((item) => item.quantity > 0);

    setCartItems(updatedCart);
  };

  const totalItems = cartItems.reduce(
    (total, item) => total + item.quantity,
    0
  );

  const totalPrice = cartItems.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  return (
    <div className="apc">
      <h1>Items</h1>

      <div className="ic">
        {items.map((item) => (
          <div key={item.id} className="item-box">
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <p>Price: ${item.price}</p>
            <button onClick={() => addToCart(item)}>Add to Cart</button>
          </div>
        ))}
      </div>

      <h1>Cart</h1>

      {cartItems.length === 0 && <p>Cart is Empty</p>}

      {cartItems.length > 0 && (
        <div className="mcm">
          <ul>
            {cartItems.map((item) => (
              <li key={item.id}>
                <span>
                  {item.name} - ${item.price} x {item.quantity}
                </span>
                <div className="dcd">
                  <button onClick={() => updateQuantity(item.id, 1)}>+</button>
                  <button onClick={() => updateQuantity(item.id, -1)}>-</button>
                  <button onClick={() => removeFromCart(item.id)}>
                    Remove
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <div className="tp">
            <div className="tr">
              <p>
                Total Items: <span>{totalItems}</span>
              </p>
              <p>
                Total Price: <span>${totalPrice}</span>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
